package com.example.tugasruangtabung;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    
    
    Button buttonhitung;
    EditText editTextTextPersonName3,editTextTextPersonName2,editTextTextPersonName1;
    TextView tvpanjang, tvlebar,tvjarijari,textVolumetabung,textluasselimut;
    int phi = (int) 22.7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonhitung = (Button) findViewById(R.id.buttonhitung);

        editTextTextPersonName1 = (EditText)findViewById(R.id.editTextTextPersonName);
        editTextTextPersonName2 =(EditText) findViewById(R.id.editTextTextPersonName2);
        editTextTextPersonName3 = (EditText)findViewById(R.id.editTextTextPersonName3);
        tvpanjang = (TextView) findViewById(R.id.tvpanjang);
        tvlebar = (TextView)findViewById(R.id.tvlebar);
        tvjarijari= (TextView)findViewById(R.id.tvjarijari);
        textluasselimut = (TextView)findViewById(R.id.textluasselimut);
        textVolumetabung = (TextView)findViewById(R.id.textVolumetabung);

        buttonhitung.setOnClickListener(v -> hitung());
    }

    private void hitung() {
        if (editTextTextPersonName1.getText().toString().trim().length()==0){
            editTextTextPersonName1.setError("Input Panjang");
        }
        if (editTextTextPersonName2.getText().toString().trim().length()==0){
            editTextTextPersonName2.setError("Input Lebar");
        }
        if (editTextTextPersonName3.getText().toString().trim().length()==0){
            editTextTextPersonName3.setError("Input Jari Jari");
        }


        int panjang = Integer.parseInt (editTextTextPersonName1.getText().toString());
        int Lebar = Integer.parseInt(editTextTextPersonName2.getText().toString());
        int jarijari = Integer.parseInt(editTextTextPersonName3.getText().toString());

        tvjarijari.setText(editTextTextPersonName3.getText().toString());
        tvlebar.setText(editTextTextPersonName2.getText().toString());
        tvpanjang.setText(editTextTextPersonName1.getText().toString());
//
        int luasselimut  = panjang* Lebar;
        int luastabung = phi*jarijari*jarijari*Lebar;

        textluasselimut.setText(Integer.toString(luasselimut));
        textVolumetabung.setText(Integer.toString(luastabung));

    }
}